
			
             
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/8db95501c26e3f30667f.jpg" alt=""/></li>
						<li><img src="images/27ff6054f73b0a65532a.jpg" alt=""/></li>
						<li><img src="images/3937f19366fc9ba2c2ed.jpg" alt=""/></li>
						<li><img src="images/381ba84b3f24c27a9b35.jpg" alt=""/></li>
						<li><img src="images/ec917039e7561a084347.jpg" alt=""/></li>
						<li><img src="images/381ba84b3f24c27a9b35.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
<!-- FlexSlider -->
	  